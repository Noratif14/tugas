# 23419035_tokenization
Simple Tokenization in HTML and JavaScript.

# UTS Teori Bahasa Formal dan Otomata

Nama      : EDI ARIANTO</br>
NIM       : 23419038</br>
Prodi     : Teknik Informatika</br>
Angkatan  : 2019 Malam</br>
