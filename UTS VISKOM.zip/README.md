# BackwardChaining
 Description link: https://nowshad7.blogspot.com/2019/09/backward-chaining.html
